// runner imports
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
// unit test imports
import org.junit.Test;
import static org.junit.Assert.assertEquals;
// imports for expected exceptions
import org.junit.Rule;
import org.junit.rules.ExpectedException;

public class ContactTest {
  
    public static void main(String[] Args) {
        Result result = JUnitCore.runClasses(ContactTest.class);

        for(Failure failure :result.getFailures()) {
            System.out.println(failure);
        }

        if(result.wasSuccessful()) {
            System.out.println("All tests ran as expected!");
        } else {
            System.out.println("Some tests failed - see the above for details.");
        }
    }

    // Inputs
    protected final String validID = "123456789";
    protected final String validFirstName = "Quigmare";
    protected final String validLastName = "Griffen";
    protected final String validPhoneNumber = "1112223333";
    protected final String validAddress = "11 family guy Drive";

    // Inputs (invalid)
    protected final String badID = "1234567890a";
    protected final String badFirstName = "TikTok";
    protected final String badLastName = "Money";
    protected final String badPhoneNumberLength = "456";
    protected final String badPhoneNumberInput = "111222333a";
    protected final String badAddress = "This is way too long of an address because it exceeds 30 characters but probably located in china";

    // The valid inputs that we can set to. 
    protected final String secondFirstName = "John";
    protected final String secondLastName = "Zelensky";
    protected final String secondPhoneNumber = "4445556666";
    protected final String secondAddress = "1112223455";

    protected final Contact goodContact = new Contact(
            validID,
            validFirstName,
            validLastName,
            validPhoneNumber,
            validAddress
    );

    protected Contact modifiedContact = goodContact;

    // Rule for exception
    @Rule
    public ExpectedException rule = ExpectedException.none();

    // Verify the object meets parameters 
    @Test
    public void verifyContact() {
        System.out.println("Checking Contact constructor");
        assertEquals(goodContact.getId(), validID);
        assertEquals(goodContact.getFirstName(), validFirstName);
        assertEquals(goodContact.getLastName(), validLastName);
        assertEquals(goodContact.getPhoneNumber(), validPhoneNumber);
        assertEquals(goodContact.getAddress(), validAddress);
    }

    // Error checking by intentionally throwing an error 
    @Test
    public void verifyBadId() {
        System.out.println("verifying id...");
        rule.expect(AssertionError.class);
        new Contact(badID, validFirstName, validLastName, validPhoneNumber, validAddress);
    }

    @Test
    public void verifyFirstName() {
        System.out.println("verifying firstName...");
        modifiedContact.setFirstName(secondFirstName);
        assertEquals(modifiedContact.getFirstName(), secondFirstName);

        // Raising of exception
        rule.expect(AssertionError.class);
        modifiedContact.setFirstName(badFirstName);
    }

    // Verify setting/getting lastName is good
    @Test
    public void verifyLastName() {
        System.out.println("verifying lastName...");
      
        modifiedContact.setLastName(secondLastName);
        assertEquals(modifiedContact.getLastName(), secondLastName);

        rule.expect(AssertionError.class);
        modifiedContact.setLastName(badLastName);
    }

    // Verify setting/getting phoneNumber is good
    @Test
    public void verifyPhoneNumber() {
        System.out.println("verifying phoneNumber...");
       
        modifiedContact.setPhoneNumber(secondPhoneNumber);
        assertEquals(modifiedContact.getPhoneNumber(), secondPhoneNumber);

 
        rule.expect(AssertionError.class);
        modifiedContact.setPhoneNumber(badPhoneNumberInput);
        modifiedContact.setPhoneNumber(badPhoneNumberLength);
    }

    @Test
    public void verifyAddress() {
        System.out.println("verifying address...");
       
        modifiedContact.setAddress(secondAddress);
        assertEquals(modifiedContact.getAddress(), secondAddress);

       
        rule.expect(AssertionError.class);
        modifiedContact.setAddress(badAddress);
    }
}
