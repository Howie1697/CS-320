/*
 * Author: Howard Gilmore
 * 
 * Task.java requirements:
 * The task object must have a unique 10-character ID String. Task ID cannot be null or updated..
 * Task objects must have names. A 20-character string field. Name cannot be null.
 * Required task object description 50-character string limit. Description cannot be null.
 */
package mobileApp;

public class Task {
	
	private String taskId, name, description;
	
	public Task(String taskId, String name, String description) {
		createTaskId(taskId);
		updateName(name);
		updateDescription(description);
	}
	
	public String getTaskId() {
		return taskId;
	}
	
	public String getName() {
		return name;
	}
	
	public String getDescription() {
		return description;
	}

	protected void createTaskId(String taskId) {	
		if(taskId == null) {
			
			throw new IllegalArgumentException("Task ID is null");
			
		} else if (taskId.length() > 10) {
			
			throw new IllegalArgumentException("Task ID cannot be longer than 10 characters.");
			
		} else {
			this.taskId = taskId;
		}
	}
	
	protected void updateName(String name) {
		if(name == null) {
			
			throw new IllegalArgumentException("Name is null");
			
		} else if (name.length() > 20) {
			
			throw new IllegalArgumentException("Name cannot be longer than 20 characters");
			
		} else {
			
			this.name = name;
		}
	}
	
	protected void updateDescription(String description) {
		if(description == null) {
			
			throw new IllegalArgumentException("Description is null");
			
		} else if (description.length() > 50) {
			
			throw new IllegalArgumentException("Description cannot be longer than 50 characters");
			
		} else {
			this.description = description;
		}
	}
}
