import java.util.ArrayList;
// Implementation of the ContactService class, which has knowledge of
// a collection of contacts and organizes them by ID
public class ContactService {
    // Note - we use a simple ArrayList for our contacts, so lookup
    // is linear time. If performance must be better, we could use a map from
    // ID to contacts for constant time lookup
    private ArrayList<Contact> contactList;

    /**
     * constructor for ContactService
     */
    public ContactService() {
        contactList = new ArrayList<Contact>();
    }

  
    public ContactService(Contact contact) {
        contactList = new ArrayList<Contact>();
        contactList.add(contact);
    }
 
    public boolean insertContact(Contact contact) {
        // Walk through our list looking for ID
        if(retrieveContact(contact.getId()) != null) {
            return false;
        }

        // No ID found, goto end of arraylist
        contactList.add(contact);
        return true;
    }

  
    public boolean removeContact(String id) {
        Contact retrieved = retrieveContact(id);
        if (retrieved != null) {
            // We can remove this contact
            contactList.remove(retrieved);
            return true;
        }

        // Did not find a matching id to remove
        return false;
    }
//Helpers will help find the first,last, and other information using @param to find them
  
    public boolean updateFirstName(String id, String firstName) {
        Contact retrieved = retrieveContact(id);
        if(retrieved != null) {
            retrieved.setFirstName(firstName);
            return true;
        }

        return false;
    }

    
    public boolean updateLastName(String id, String lastName) {
        Contact retrieved = retrieveContact(id);
        if(retrieved != null) {
            retrieved.setLastName(lastName);
            return true;
        }

        return false;
    }

    public boolean updatePhoneNumber(String id, String phoneNumber) {
        Contact retrieved = retrieveContact(id);
        if(retrieved != null) {
            retrieved.setPhoneNumber(phoneNumber);
            return true;
        }

        return false;
    }

    public boolean updateAddress(String id, String address) {
        Contact retrieved = retrieveContact(id);
        if(retrieved != null) {
            retrieved.setAddress(address);
            return true;
        }

        return false;
    }

    public Contact retrieveContact(String id) {
        for(Contact contact : contactList) {
            if(id.equals(contact.getId())) {
                return contact;
            }
        }

        return null;
    }
}
