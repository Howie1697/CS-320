// Implementation of the Contact Class
public class Contact {
    private final String id;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String address;

  
    public Contact(
        String inputId,
        String inputFirstName,
        String inputLastName,
        String inputPhoneNumber,
        String inputAddress
    ) {
        id = safeAssign(inputId, 10, "id");
        firstName = safeAssign(inputFirstName, 10, "firstName");
        lastName = safeAssign(inputLastName, 10, "lastName");
        phoneNumber = assignPN(inputPhoneNumber);
        address = safeAssign(inputAddress, 30, "address");
    }

    // Using our "get" functions to retrieve data
    public String getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    // We dont use set for ID however the rest should set the information
    public void setFirstName(String inputFirstName) {
        firstName = safeAssign(inputFirstName, 10, "firstName");
    }

    public void setLastName(String inputLastName) {
        lastName = safeAssign(inputLastName, 10, "lastName");
    }

    public void setPhoneNumber(String inputPhoneNumber) {
        phoneNumber = assignPN(inputPhoneNumber);
    }

    public void setAddress(String inputAddress) {
        address = safeAssign(inputAddress, 30, "address");
    }
    /**
     * I deceided to use a helper function.
     * @param input - Will input string checking
     * @param limit - Ensures that it is not null and has length 
     * @param message - The error message we will receive is there is one
     * @return - Return function, will return error is such exist
     */
    private String safeAssign(String input, int limit, String message) {
        assert (input != null && input.length() <= limit): message + ": size limit exceeded";
        return input;
    }

    
    private String assignPN(String phoneNumber) {
        assert (phoneNumber != null && phoneNumber.length() == 10) : "phoneNumber: size is NOT 10";
        assert allDigits(phoneNumber) : "phoneNumber contains non-numeric character";
        return phoneNumber;
    }

 
    private boolean allDigits(String s) {
        try {
            Long.parseLong(s);
            return true;
        } catch(NumberFormatException e) {
            return false;
        }
    }
}
